package com.piragua.buildinfo

class BuildInfoController {

    def index = { }
}
